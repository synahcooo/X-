# X2 Android 12.02.31

Android WebView wrapper for X. The project aims to preserve X website navigation, search, forms, account language preferences, cookies and local storage.

## Changes in 12.02.31

- Keeps the X account language and translation preferences intact; no forced `?lang=zh-cn` parameter or custom language request header is applied.
- Bundles the Simplified Chinese UI dictionary in the APK. Exact interface labels are localized without rewriting post bodies, comments, direct messages or editable content.
- Attempts per-post translation only when X exposes its own translation control. Actual translation remains dependent on X and the account's language settings.
- Hides the “Get the app” control using accessible labels, test IDs, links and visible nested text.
- Hides the redundant “Email or username” caption while leaving the username field itself untouched. No transparent overlay is placed above inputs or search controls, preserving long-press, selection and paste behavior.
- Third-party login options are blocked at the control event, without a floating overlay over the page.
- Persists the most recent X URL and scroll position in app preferences; the page also saves scroll position in its own origin-scoped local storage on scroll/page hide. On relaunch, the app opens the last successful X URL and attempts to restore the previous scroll position.
- Keeps WebView cookies, DOM storage and its normal disk cache. WebView history snapshots are retained for in-process restoration after a failed navigation; across full process restarts, URL/scroll/cache are the durable fallback rather than a serialized WebView object.
- Main-frame network failures are covered by a native, X-inspired retry surface. The failed WebView document is not presented as the user-facing error page. The overlay remains until a validated connection and successful page load; retry and automatic network recovery return to the last successful URL.
- The native offline surface has accessible navigation targets for Home, Search, Explore, Notifications and Messages. Navigation requires a working network.
- System Insets handle status/navigation bars and display cutouts. Only a transparent 1dp top and 1dp bottom reserve is added.

## Build

Open the `X2-Android` folder in Android Studio or build it with a configured Android Gradle environment. The build verifies that `app/src/main/assets/i18n/zh-CN.json` exists and contains required entries.

## Limits

- This is a WebView wrapper, not the official X native app.
- X may change its DOM, labels, search flow or translation controls; selectors may need maintenance.
- The bundled dictionary localizes interface text. It is not an offline machine-translation engine for arbitrary post text.
- The ZIP contains source code, not a prebuilt APK. Android SDK/Gradle compilation and real-device tests are required before runtime behavior can be certified.
