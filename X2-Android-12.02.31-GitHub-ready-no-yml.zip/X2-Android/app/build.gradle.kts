plugins {
    id("com.android.application")
}

android {
    namespace = "com.independent.xclient"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.independent.xclient"
        minSdk = 23
        targetSdk = 35
        versionCode = 120231
        versionName = "12.02.31"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            // Keep the confirmed applicationId identical in the debug APK.
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.activity:activity:1.10.0")
    implementation("androidx.webkit:webkit:1.12.1")
}


// Fail the GitHub build early if the bundled Simplified Chinese pack is missing or incomplete.
tasks.register("verifyChineseLanguagePack") {
    doLast {
        val pack = file("src/main/assets/i18n/zh-CN.json")
        check(pack.exists()) { "Missing bundled language pack: ${pack.path}" }
        val content = pack.readText(Charsets.UTF_8)
        listOf("zh-CN", "网络连接失败", "输入用户名", "使用 Google 继续", "翻译帖子", "获取应用").forEach { required ->
            check(content.contains(required)) { "Chinese language pack is missing required entry: $required" }
        }
    }
}
tasks.named("preBuild").configure {
    dependsOn("verifyChineseLanguagePack")
}
