(() => {
  'use strict';
  if (window.__x2ControlsInstalled) return;
  window.__x2ControlsInstalled = true;

  const pack = window.__X2_ZH_DICT__ || {};
  const dict = pack.strings || {};
  const appText = pack.app || {};
  const norm = value => String(value || '').replace(/\s+/g, ' ').trim();
  const messages = {
    phone: appText.phoneUnsupported || '您的手机号码不支持',
    google: appText.googleServiceError || '该设备谷歌服务异常',
    apple: appText.appleUnsupported || '不支持非apple系统'
  };
  const originalText = new WeakMap();
  const translatedPosts = new WeakSet();
  let toastTimer = 0;
  let applyQueued = false;
  let started = false;

  const css = `
    .x2-hidden-get-app { display:none !important; visibility:hidden !important; pointer-events:none !important; }
    .x2-hidden-login-label { display:none !important; }
    .x2-toast { position:fixed !important; z-index:2147483647 !important; left:50% !important; bottom:max(28px,env(safe-area-inset-bottom)) !important; transform:translateX(-50%) !important; max-width:calc(100vw - 40px) !important; padding:12px 18px !important; border-radius:12px !important; background:rgba(25,25,25,.96) !important; color:#fff !important; font:14px/1.45 sans-serif !important; text-align:center !important; box-shadow:0 4px 18px rgba(0,0,0,.25) !important; }
  `;

  function installStyle() {
    const host = document.head || document.documentElement;
    if (!host || document.getElementById('x2-controls-style')) return;
    const style = document.createElement('style');
    style.id = 'x2-controls-style';
    style.textContent = css;
    host.appendChild(style);
  }

  function toast(message) {
    if (!document.body) return;
    let node = document.getElementById('x2-toast');
    if (!node) {
      node = document.createElement('div');
      node.id = 'x2-toast';
      node.className = 'x2-toast';
      node.setAttribute('role', 'status');
      document.body.appendChild(node);
    }
    node.textContent = message;
    node.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { if (node.isConnected) node.hidden = true; }, 2300);
  }

  function buttonText(el) {
    return norm(el && (el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title')));
  }

  // Avoid treating X's search box (often input[name=text]) as a login form.
  function isLoginScreen() {
    if (/\/(i\/flow\/login|login|account\/access)(\/|$)/i.test(location.pathname)) return true;
    const hasPassword = !!document.querySelector('input[type="password"]');
    const hasAccountField = !!document.querySelector('input[autocomplete*="username" i],input[placeholder*="email" i],input[placeholder*="电子邮箱"],input[placeholder*="用户名"]');
    const hasLoginHeading = Array.from(document.querySelectorAll('h1,[role="heading"]')).some(el => /sign in|log in|登录/i.test(buttonText(el)));
    return hasPassword && (hasAccountField || hasLoginHeading);
  }

  function thirdPartyKind(el) {
    if (!el || !el.getAttribute) return null;
    const descendants = el.querySelectorAll ? Array.from(el.querySelectorAll('[aria-label],[title],[data-testid]'))
      .map(node => `${node.getAttribute('aria-label') || ''} ${node.getAttribute('title') || ''} ${node.getAttribute('data-testid') || ''}`).join(' ') : '';
    const combined = `${buttonText(el)} ${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.getAttribute('data-testid') || ''} ${descendants}`.toLowerCase();
    if (/(使用\s*手机\s*继续|continue\s*with\s*phone|phone_login)/i.test(combined)) return 'phone';
    if (/(使用\s*google\s*继续|continue\s*with\s*google|sign\s*in\s*with\s*google|google_login)/i.test(combined)) return 'google';
    if (/(使用\s*apple\s*继续|continue\s*with\s*apple|sign\s*in\s*with\s*apple|apple_login)/i.test(combined)) return 'apple';
    return null;
  }

  function isGetAppText(value) {
    return /^(get the app|get app|获取应用|下载应用)$/i.test(norm(value));
  }

  function hideGetApp() {
    if (!document.body) return;
    // First pass: semantic controls and explicit accessibility/test attributes.
    document.querySelectorAll('button,a,[role="button"],[tabindex],[aria-label],[title],[data-testid]').forEach(el => {
      const meta = `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.getAttribute('data-testid') || ''} ${el.getAttribute('href') || ''}`;
      if (/get.?app|获取应用|下载应用|\/download/i.test(meta) || isGetAppText(buttonText(el))) {
        el.classList.add('x2-hidden-get-app');
      }
    });
    // Second pass: find the visible label even when X nests it in several spans/divs.
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const matches = [];
    while (walker.nextNode()) if (isGetAppText(walker.currentNode.nodeValue)) matches.push(walker.currentNode);
    matches.forEach(node => {
      let el = node.parentElement;
      let chosen = null;
      for (let depth = 0; el && depth < 9; depth++, el = el.parentElement) {
        if (el.matches && el.matches('button,a,[role="button"],[data-testid*="getApp" i],[data-testid*="get_app" i]')) { chosen = el; break; }
        const rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
        if (!chosen && rect && rect.width > 120 && rect.height > 32) chosen = el;
      }
      if (chosen) chosen.classList.add('x2-hidden-get-app');
    });
  }

  function hideEmailUsernameCaption() {
    if (!isLoginScreen()) return;
    const captionPattern = /^(电子邮箱或用户名|电子邮件或用户名|email or username|email address or username|phone, email, or username)$/i;
    document.querySelectorAll('label,[id]').forEach(el => {
      if (el.matches('input,textarea,button')) return;
      if (!captionPattern.test(norm(el.textContent))) return;
      if (el.querySelector('input,textarea')) return;
      el.classList.add('x2-hidden-login-label');
    });
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const captions = [];
    while (walker.nextNode()) if (captionPattern.test(norm(walker.currentNode.nodeValue))) captions.push(walker.currentNode);
    captions.forEach(node => {
      let el = node.parentElement;
      for (let depth = 0; el && depth < 4; depth++, el = el.parentElement) {
        if (el.matches('input,textarea,button') || el.querySelector('input,textarea')) break;
        if (el.matches('label,[role="label"]')) { el.classList.add('x2-hidden-login-label'); break; }
        const rect = el.getBoundingClientRect();
        if (rect.height > 12 && rect.height < 90 && rect.width > 40) { el.classList.add('x2-hidden-login-label'); break; }
      }
    });
    // Keep the real editable input untouched; only change its placeholder.
    document.querySelectorAll('input:not([type="password"]),textarea').forEach(input => {
      const sig = `${input.getAttribute('autocomplete') || ''} ${input.getAttribute('name') || ''} ${input.getAttribute('placeholder') || ''} ${input.getAttribute('aria-label') || ''}`.toLowerCase();
      if (!/(email|username|电子邮箱|电子邮件|用户名)/i.test(sig) || /(search|搜索)/i.test(sig)) return;
      if (input.getAttribute('placeholder') !== (appText.usernamePlaceholder || '输入用户名')) {
        input.setAttribute('placeholder', appText.usernamePlaceholder || '输入用户名');
      }
    });
  }

  function translateExactText() {
    if (!document.body) return;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !norm(node.nodeValue)) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|OPTION)$/i.test(parent.tagName)) return NodeFilter.FILTER_REJECT;
        if (parent.closest('[data-testid="tweetText"],[data-testid="tweetPhoto"],[data-testid="UserDescription"],[contenteditable="true"]')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      const raw = node.nodeValue;
      const key = norm(raw);
      if (!Object.prototype.hasOwnProperty.call(dict, key)) return;
      if (!originalText.has(node)) originalText.set(node, raw);
      const replacement = dict[key];
      const next = `${raw.match(/^\s*/)?.[0] || ''}${replacement}${raw.match(/\s*$/)?.[0] || ''}`;
      if (node.nodeValue !== next) node.nodeValue = next;
    });
    document.querySelectorAll('input,textarea,[aria-label],[title]').forEach(el => {
      const ph = el.getAttribute('placeholder');
      if (ph && dict[norm(ph)]) el.setAttribute('placeholder', dict[norm(ph)]);
      const aria = el.getAttribute('aria-label');
      if (aria && dict[norm(aria)]) el.setAttribute('aria-label', dict[norm(aria)]);
      const title = el.getAttribute('title');
      if (title && dict[norm(title)]) el.setAttribute('title', dict[norm(title)]);
    });
  }

  // No transparent overlays are placed above the page: this protects search, input,
  // long-press selection and Android's native paste menu.
  function blockUnsupportedLoginAction(event) {
    if (!isLoginScreen()) return;
    const target = event.target;
    const control = target && target.closest ? target.closest('button,[role="button"],a,[tabindex="0"]') : null;
    if (!control) return;
    const kind = thirdPartyKind(control);
    if (!kind) return;
    if (event.type === 'keydown' && !['Enter',' '].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    if (event.type === 'click' || event.type === 'keydown' || event.type === 'pointerdown') toast(messages[kind]);
  }

  function autoTranslateVisiblePosts() {
    // Preserve the account's X language preferences; only invoke a translation action
    // when X itself exposes an explicit control for an individual post.
    const translate = /(translate post|translate this post|翻译帖子|翻译此帖子|翻译推文)/i;
    const alreadyTranslated = /(show original|显示原文|hide translation|隐藏翻译)/i;
    const cards = Array.from(document.querySelectorAll('article,[data-testid="tweet"],[data-testid="cellInnerDiv"]'));
    cards.forEach(card => {
      if (translatedPosts.has(card)) return;
      const controls = Array.from(card.querySelectorAll('button,[role="button"],a'));
      for (const control of controls) {
        const label = norm(`${buttonText(control)} ${control.getAttribute('aria-label') || ''} ${control.getAttribute('title') || ''}`);
        if (alreadyTranslated.test(label)) { translatedPosts.add(card); return; }
        if (!translate.test(label) || control.disabled || control.getAttribute('aria-disabled') === 'true') continue;
        const rect = control.getBoundingClientRect();
        if (rect.width < 4 || rect.height < 4 || rect.bottom < 0 || rect.top > innerHeight) continue;
        translatedPosts.add(card);
        try { control.click(); } catch (_) { translatedPosts.delete(card); }
        return;
      }
    });
  }

  function apply() {
    applyQueued = false;
    if (!document.body) return;
    installStyle();
    hideGetApp();
    hideEmailUsernameCaption();
    translateExactText();
    autoTranslateVisiblePosts();
  }

  function scheduleApply() {
    if (applyQueued) return;
    applyQueued = true;
    (window.requestAnimationFrame || (fn => setTimeout(fn, 0)))(apply);
  }

  function start() {
    if (started) return;
    started = true;
    installStyle();
    // Do not overwrite document.lang or account language preferences.
    const root = document.documentElement;
    if (root) {
      const observer = new MutationObserver(scheduleApply);
      observer.observe(root, { childList:true, subtree:true, characterData:true, attributes:true,
        attributeFilter:['placeholder','aria-label','title','data-testid','href'] });
    }
    ['click','keydown','pointerdown'].forEach(type => {
      document.addEventListener(type, blockUnsupportedLoginAction, { capture:true, passive:false });
    });
    window.addEventListener('resize', scheduleApply, { passive:true });
    window.addEventListener('scroll', scheduleApply, { passive:true, capture:true });
    window.addEventListener('popstate', scheduleApply);
    window.addEventListener('pageshow', scheduleApply);
    window.addEventListener('hashchange', scheduleApply);
    document.addEventListener('visibilitychange', scheduleApply);
    scheduleApply();
    setInterval(scheduleApply, 2400);
  }

  if (document.documentElement) start();
  else document.addEventListener('DOMContentLoaded', start, { once:true });
})();
