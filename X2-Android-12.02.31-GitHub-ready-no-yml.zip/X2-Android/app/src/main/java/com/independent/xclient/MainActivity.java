package com.independent.xclient;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.CookieManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewCompat;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private static final String HOME_URL = "https://x.com/";
    // System insets already protect the status bar/cutout; keep only a 1dp extra reserve.
    private static final int EXTRA_TOP_DP = 1;
    private static final int EXTRA_BOTTOM_DP = 1;
    private static final long OFFLINE_PROBE_MS = 2200L;

    private FrameLayout root;
    private FrameLayout webSafeFrame;
    private WebView webView;
    private FrameLayout offlineView;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean online;
    private boolean offlinePageShown;
    private String lastSuccessfulUrl = HOME_URL;
    private Bundle lastGoodWebState;
    private boolean pageLoadInProgress;
    private boolean mainFrameFailed;
    private boolean networkCallbackRegistered;
    private long lastBackPressed;
    private long lastAutoReloadAt;
    private long offlineRetryDelayMs = OFFLINE_PROBE_MS;
    private float refreshTouchStartY;
    private boolean refreshStartedAtTop;
    private boolean restoreScrollPending = true;
    private static final String STATE_WEBVIEW = "x2_webview_state";
    private static final String PREFS = "x2_session_cache";
    private static final String PREF_URL = "last_url";
    private static final String PREF_SCROLL = "last_scroll_y";
    private static final String PREF_LAST_GOOD_URL = "last_good_url";

    private final Runnable offlineProbe = new Runnable() {
        @Override public void run() {
            if (isFinishing() || !offlinePageShown) return;
            if (hasValidatedNetwork()) {
                recoverNetwork();
            } else {
                handler.postDelayed(this, offlineRetryDelayMs);
                offlineRetryDelayMs = Math.min(30000L, offlineRetryDelayMs * 2L);
            }
        }
    };

    @Override
    protected void attachBaseContext(Context newBase) {
        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        Locale zh = Locale.SIMPLIFIED_CHINESE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(new android.os.LocaleList(zh));
        } else {
            config.locale = zh;
        }
        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureImmersiveWindow();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
        // Explicit edge-to-edge inset handling also covers Android 15+ enforcement,
        // display cutouts and gesture navigation. A separate fixed reserve is added below.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            androidx.core.graphics.Insets bars = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            androidx.core.graphics.Insets ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        webSafeFrame = new FrameLayout(this);
        webSafeFrame.setBackgroundColor(Color.TRANSPARENT);
        webSafeFrame.setPadding(0, dp(EXTRA_TOP_DP), 0, dp(EXTRA_BOTTOM_DP));
        webSafeFrame.setClipToPadding(true);
        root.addView(webSafeFrame, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setStandardFontFamily("sans-serif");
        webView.getSettings().setSansSerifFontFamily("sans-serif");
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.getSettings().setCacheMode(hasValidatedNetwork() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }
        webView.setVisibility(View.VISIBLE);
        installDocumentStartControls();
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep X and its authentication flow inside this app's WebView.
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageLoadInProgress = true;
                if (!offlinePageShown && hasValidatedNetwork()) mainFrameFailed = false;
                // Keep the native offline surface above any failed/cached document until the network is validated.
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoadInProgress = false;
                Runnable finishPage = () -> {
                    if (!mainFrameFailed && hasValidatedNetwork()) {
                        offlineRetryDelayMs = OFFLINE_PROBE_MS;
                        offlinePageShown = false;
                        showWeb();
                        if (url != null && url.startsWith("https://x.com")) {
                            lastSuccessfulUrl = url;
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                    .putString(PREF_LAST_GOOD_URL, url).apply();
                            try {
                                Bundle snapshot = new Bundle();
                                if (webView.saveState(snapshot) != null) lastGoodWebState = snapshot;
                            } catch (Exception ignored) { }
                        }
                        rememberCurrentPage(url);
                        restoreRecentScroll();
                    } else {
                        showOffline();
                    }
                };
                if (url != null && (url.startsWith("https://x.com/") || url.equals("https://x.com")
                        || url.startsWith("https://twitter.com/"))) {
                    injectX2Controls(finishPage);
                } else {
                    handler.postDelayed(finishPage, 350L);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    pageLoadInProgress = false;
                    mainFrameFailed = true;
                    showOffline();
                    restoreLastPageAfterFailure(request.getUrl().toString());
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            android.webkit.WebResourceResponse response) {
                if (request != null && request.isForMainFrame() && response != null
                        && response.getStatusCode() >= 500) {
                    pageLoadInProgress = false;
                    mainFrameFailed = true;
                    showOffline();
                    restoreLastPageAfterFailure(request.getUrl().toString());
                }
            }

            @Override
            public void onReceivedSslError(WebView view, android.webkit.SslErrorHandler handler,
                                           android.net.http.SslError error) {
                handler.cancel();
                if (error != null && error.getUrl() != null && error.getUrl().contains("x.com")) {
                    pageLoadInProgress = false;
                    mainFrameFailed = true;
                    showOffline();
                    restoreLastPageAfterFailure(error.getUrl());
                }
            }
        });
        webSafeFrame.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // Pull down while already at the top to manually refresh, without adding a permanent toolbar.
        webView.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                refreshTouchStartY = event.getY();
                refreshStartedAtTop = webView.getScrollY() <= dp(2);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                float distance = event.getY() - refreshTouchStartY;
                if (refreshStartedAtTop && distance > dp(115) && webView.getScrollY() <= dp(2)) {
                    refreshPage();
                }
            }
            return false;
        });

        // Native app-styled offline surface. It covers any WebView-generated error
        // document while leaving the WebView and its last rendered state underneath.
        offlineView = buildOfflineView();
        offlineView.setVisibility(View.GONE);
        root.addView(offlineView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        online = hasValidatedNetwork();
        boolean restored = false;
        if (savedInstanceState != null && savedInstanceState.containsKey(STATE_WEBVIEW)) {
            try {
                Bundle webState = savedInstanceState.getBundle(STATE_WEBVIEW);
                restored = webState != null && webView.restoreState(webState) != null;
            } catch (Exception ignored) { }
        }
        if (restored) {
            pageLoadInProgress = true;
            webView.setVisibility(View.VISIBLE);
        } else {
            loadHome();
        }
        registerNetworkMonitor();
        installBackHandling();
        applySafeAreaAgain();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void configureImmersiveWindow() {
        Window window = getWindow();
        // System Insets handle status/navigation bars and cutouts; the content reserve is only 1dp.
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.BLACK);
        window.setNavigationBarColor(Color.BLACK);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        androidx.core.view.WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(window, window.getDecorView());
        if (controller != null) {
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
        }
    }

    private void applySafeAreaAgain() {
        if (webSafeFrame == null) return;
        // System Insets do the real avoidance; only a transparent 1dp rollback guard remains.
        webSafeFrame.setPadding(0, dp(EXTRA_TOP_DP), 0, dp(EXTRA_BOTTOM_DP));
        webSafeFrame.setClipToPadding(true);
        if (root != null) androidx.core.view.ViewCompat.requestApplyInsets(root);
    }

    private void loadHome() {
        if (webView == null) return;
        pageLoadInProgress = true;
        mainFrameFailed = false;
        webView.setVisibility(View.VISIBLE);
        boolean connected = hasValidatedNetwork();
        webView.getSettings().setCacheMode(connected ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        String lastUrl = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(PREF_LAST_GOOD_URL, getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_URL, HOME_URL));
        if (lastUrl == null || !(lastUrl.startsWith("https://x.com/") || lastUrl.equals("https://x.com"))) lastUrl = HOME_URL;
        lastSuccessfulUrl = lastUrl;
        restoreScrollPending = true;
        webView.loadUrl(lastUrl);
    }

    private void rememberCurrentPage(String url) {
        if (url == null || !(url.startsWith("https://x.com/") || url.equals("https://x.com"))) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_URL, url).apply();
    }

    private void restoreRecentScroll() {
        if (!restoreScrollPending || webView == null) return;
        restoreScrollPending = false;
        int y = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(PREF_SCROLL, 0);
        if (y > 0) webView.evaluateJavascript("try{window.scrollTo(0," + y + ");}catch(e){}", null);
    }

    private void saveRecentScroll() {
        if (webView == null) return;
        webView.evaluateJavascript("(function(){try{var y=Math.max(0,Math.round(window.scrollY||document.documentElement.scrollTop||0));localStorage.setItem('__x2_last_scroll',String(y));return String(y)}catch(e){return '0'}})()", value -> {
            try {
                int y = Integer.parseInt(value == null ? "0" : value.replaceAll("[^0-9]", ""));
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(PREF_SCROLL, y).apply();
            } catch (Exception ignored) { }
        });
        rememberCurrentPage(webView.getUrl());
    }

    private void refreshPage() {
        if (webView == null) return;
        if (!hasValidatedNetwork()) {
            showOffline();
            return;
        }
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        pageLoadInProgress = true;
        mainFrameFailed = false;
        webView.reload();
    }

    private String readAsset(String name) throws Exception {
        try (InputStream input = getAssets().open(name);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String buildControlScript() throws Exception {
        String script = readAsset("x2-controls.js");
        String dictionary = readAsset("i18n/zh-CN.json");
        // The dictionary is shipped inside the APK and injected locally: no first-run network dependency.
        JSONObject parsed = new JSONObject(dictionary);
        String sessionScript = "(function(){try{if(window.__x2SessionCache)return;window.__x2SessionCache=true;" +
                "var key='__x2_last_scroll';var save=function(){try{localStorage.setItem(key,String(Math.max(0,Math.round(window.scrollY||document.documentElement.scrollTop||0))))}catch(e){}};" +
                "var timer=0;window.addEventListener('scroll',function(){clearTimeout(timer);timer=setTimeout(save,450)},{passive:true});" +
                "window.addEventListener('pagehide',save);document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')save()});" +
                "var restore=function(){try{var y=parseInt(localStorage.getItem(key)||'0',10);if(y>0)window.scrollTo(0,y)}catch(e){}};" +
                "setTimeout(restore,700);setTimeout(restore,1700);" +
                "})();";
        return "window.__X2_ZH_DICT__=" + parsed.toString() + ";\n" + sessionScript + "\n" + script;
    }

    private void installDocumentStartControls() {
        if (webView == null) return;
        try {
            String script = buildControlScript();
            WebViewCompat.addDocumentStartJavaScript(webView, script,
                    Collections.singleton("https://x.com/*"));
        } catch (Exception ignored) {
            // The native visibility gate and onPageFinished injection remain independent fallbacks.
        }
    }

    private void injectX2Controls(Runnable afterInjection) {
        if (webView == null || isFinishing()) return;
        try {
            webView.evaluateJavascript(buildControlScript(), result -> {
                if (afterInjection != null && !isFinishing()) handler.postDelayed(afterInjection, 350L);
            });
        } catch (Exception ignored) {
            if (afterInjection != null) handler.postDelayed(afterInjection, 350L);
        }
    }

    private boolean hasValidatedNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network active = cm.getActiveNetwork();
                if (active == null) return false;
                NetworkCapabilities caps = cm.getNetworkCapabilities(active);
                return caps != null
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            }
            android.net.NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception ignored) {
            return false;
        }
    }

    private FrameLayout buildOfflineView() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.WHITE);
        overlay.setClickable(true);
        overlay.setFocusable(true);
        overlay.setContentDescription("网络连接提示");

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        overlay.addView(page, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout top = new FrameLayout(this);
        TextView logo = new TextView(this);
        logo.setText("𝕏");
        logo.setTextColor(Color.BLACK);
        logo.setTextSize(34);
        logo.setGravity(Gravity.CENTER);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(logo, new FrameLayout.LayoutParams(dp(64), dp(56), Gravity.CENTER));
        page.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(76)));

        FrameLayout center = new FrameLayout(this);
        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView cloud = new TextView(this);
        cloud.setText("☁̸");
        cloud.setTextColor(Color.rgb(83, 100, 113));
        cloud.setTextSize(56);
        cloud.setGravity(Gravity.CENTER);
        group.addView(cloud, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(78)));

        TextView message = new TextView(this);
        message.setText("你的网络连接似乎出了问题。请检查并重试。");
        message.setTextColor(Color.rgb(83, 100, 113));
        message.setTextSize(17);
        message.setGravity(Gravity.CENTER);
        message.setMaxWidth(dp(340));
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        messageLp.setMargins(dp(24), dp(12), dp(24), dp(28));
        group.addView(message, messageLp);

        Button retry = new Button(this);
        retry.setText("⟳  重试");
        retry.setTextColor(Color.WHITE);
        retry.setTextSize(16);
        retry.setAllCaps(false);
        retry.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(Color.rgb(29, 155, 240));
        pill.setCornerRadius(dp(32));
        retry.setBackground(pill);
        retry.setMinWidth(dp(132));
        retry.setMinHeight(dp(48));
        retry.setPadding(dp(22), 0, dp(22), 0);
        retry.setOnClickListener(v -> retryIfOnline());
        group.addView(retry);

        FrameLayout.LayoutParams groupLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        groupLp.topMargin = dp(150);
        center.addView(group, groupLp);
        page.addView(center, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(10), dp(8), dp(10), dp(8));
        String[] symbols = {"⌂", "⌕", "◉", "♧", "☏"};
        String[] destinations = {"https://x.com/home", "https://x.com/search", "https://x.com/explore", "https://x.com/notifications", "https://x.com/messages"};
        String[] labels = {"主页", "搜索", "探索", "通知", "私信"};
        for (int i = 0; i < symbols.length; i++) {
            final String destination = destinations[i];
            TextView item = new TextView(this);
            item.setText(symbols[i]);
            item.setTextColor(Color.rgb(15, 20, 25));
            item.setTextSize(27);
            item.setGravity(Gravity.CENTER);
            item.setFocusable(true);
            item.setClickable(true);
            item.setContentDescription(labels[i]);
            item.setOnClickListener(v -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_URL, destination).apply();
                if (hasValidatedNetwork()) {
                    lastSuccessfulUrl = destination;
                    offlinePageShown = false;
                    mainFrameFailed = false;
                    pageLoadInProgress = true;
                    webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
                    webView.loadUrl(destination);
                    offlineView.setVisibility(View.GONE);
                } else {
                    Toast.makeText(MainActivity.this, "网络连接失败，请恢复网络后重试", Toast.LENGTH_SHORT).show();
                }
            });
            nav.addView(item, new LinearLayout.LayoutParams(0, dp(54), 1f));
        }
        page.addView(nav, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(66)));
        return overlay;
    }

    private void showOffline() {
        // Keep the WebView underneath, but cover any browser-generated failure document
        // with the native X-styled retry surface.
        offlinePageShown = true;
        online = false;
        pageLoadInProgress = false;
        if (offlineView != null) offlineView.setVisibility(View.VISIBLE);
        if (webView != null) webView.setVisibility(View.VISIBLE);
        handler.removeCallbacks(offlineProbe);
        handler.postDelayed(offlineProbe, offlineRetryDelayMs);
    }

    private void restoreLastPageAfterFailure(String failedUrl) {
        if (webView == null) return;
        handler.postDelayed(() -> {
            if (isFinishing() || !mainFrameFailed) return;
            String current = webView.getUrl();
            webView.stopLoading();
            boolean restored = false;
            if (lastGoodWebState != null) {
                try { restored = webView.restoreState(lastGoodWebState) != null; }
                catch (Exception ignored) { restored = false; }
            }
            if (!restored && lastSuccessfulUrl != null
                    && lastSuccessfulUrl.startsWith("https://x.com")) {
                webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                webView.loadUrl(lastSuccessfulUrl);
            }
            webView.setVisibility(View.VISIBLE);
        }, 120L);
    }

    private void showWeb() {
        if (offlineView != null) offlineView.setVisibility(View.GONE);
        if (webView != null) webView.setVisibility(View.VISIBLE);
        offlinePageShown = false;
        handler.removeCallbacks(offlineProbe);
    }

    private void retryIfOnline() {
        if (hasValidatedNetwork()) {
            recoverNetwork();
        } else {
            if (offlineView != null) offlineView.setVisibility(View.VISIBLE);
        }
    }

    private void recoverNetwork() {
        if (webView == null || isFinishing()) return;
        long now = System.currentTimeMillis();
        // Debounce duplicate callbacks from onAvailable/onCapabilitiesChanged/polling.
        if (now - lastAutoReloadAt < 1800L && pageLoadInProgress) return;
        lastAutoReloadAt = now;
        online = true;
        // Keep the native retry surface visible until a successful page finish callback.
        pageLoadInProgress = true;
        mainFrameFailed = false;
        webView.setVisibility(View.VISIBLE);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setVisibility(View.VISIBLE);
        String target = lastSuccessfulUrl;
        if (target == null || !target.startsWith("https://x.com")) target = HOME_URL;
        webView.loadUrl(target);
    }

    private void registerNetworkMonitor() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                handler.postDelayed(() -> {
                    if (hasValidatedNetwork() && offlinePageShown) recoverNetwork();
                }, 900L);
            }
            @Override public void onLost(Network network) {
                handler.post(() -> {
                    // Do not replace the WebView while it is trying to restore cached content.
                });
            }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                handler.post(() -> {
                    if (hasValidatedNetwork()) {
                        if (offlinePageShown) recoverNetwork();
                    }
                    // Keep the last rendered feed visible during a temporary outage; the
                    // cache/offline screen is used only if a main-frame load actually fails.
                });
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(networkCallback);
            } else {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
                connectivityManager.registerNetworkCallback(request, networkCallback);
            }
            networkCallbackRegistered = true;
        } catch (Exception ignored) {
            networkCallbackRegistered = false;
            // The offline polling loop and onResume checks still work without callbacks.
        }
    }

    private void installBackHandling() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                // Android normally lets the IME consume Back first; this is an explicit second check.
                if (isKeyboardVisible()) {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                    setEnabled(true);
                    return;
                }
                if (offlinePageShown) {
                    retryIfOnline();
                    return;
                }
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastBackPressed < 2000L) finish();
                else {
                    lastBackPressed = now;
                    Toast.makeText(MainActivity.this, "再按一次返回键退出", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isKeyboardVisible() {
        try {
            return WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()) != null
                    && androidx.core.view.ViewCompat.getRootWindowInsets(getWindow().getDecorView()) != null
                    && androidx.core.view.ViewCompat.getRootWindowInsets(getWindow().getDecorView())
                    .isVisible(WindowInsetsCompat.Type.ime());
        } catch (Exception ignored) {
            return false;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) {
            try {
                Bundle webState = new Bundle();
                webView.saveState(webState);
                outState.putBundle(STATE_WEBVIEW, webState);
            } catch (Exception ignored) { }
            saveRecentScroll();
        }
        super.onSaveInstanceState(outState);
    }

    @Override protected void onPause() {
        saveRecentScroll();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        configureImmersiveWindow();
        applySafeAreaAgain();
        if (webView != null && hasValidatedNetwork()
                && offlinePageShown) recoverNetwork();
        else if (webView != null && !hasValidatedNetwork() && webView.getUrl() != null) {
            webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (connectivityManager != null && networkCallback != null && networkCallbackRegistered) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) { }
        }
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
