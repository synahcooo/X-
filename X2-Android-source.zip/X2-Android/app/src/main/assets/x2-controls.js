(() => {
  'use strict';
  if (window.__x2ControlsInstalled) return;
  window.__x2ControlsInstalled = true;

  const blockedMessage = '此登录方式在 X₂ 中暂不可用，请使用邮箱或用户名继续登录。';
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const isLoggedIn = () => {
    const p = location.pathname;
    if (/^\/(i\/flow\/login|login|account\/access)/i.test(p)) return false;
    return p === '/home' || p.startsWith('/home/') ||
      !!document.querySelector('[data-testid="AppTabBar_Home_Link"], nav[aria-label="Primary"], [data-testid="SideNav_AccountSwitcher_Button"]');
  };
  const isLoginScreen = () => /\/(i\/flow\/login|login)(\/|$)/i.test(location.pathname) ||
    !!Array.from(document.querySelectorAll('input')).find(el => /email|username|phone/i.test((el.getAttribute('autocomplete') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + (el.getAttribute('placeholder') || '')));

  const style = document.createElement('style');
  style.id = 'x2-controls-style';
  style.textContent = `
    input[placeholder], textarea[placeholder] { }
    .x2-hidden-placeholder::placeholder { color: transparent !important; opacity: 0 !important; }
    .x2-blocked-entry { position: relative !important; }
    .x2-toast { position: fixed; z-index: 2147483647; left: 50%; bottom: max(28px, env(safe-area-inset-bottom)); transform: translateX(-50%); max-width: calc(100vw - 40px); padding: 12px 18px; border-radius: 12px; background: rgba(25,25,25,.96); color: #fff; font: 14px/1.45 system-ui,sans-serif; text-align: center; box-shadow: 0 4px 18px rgba(0,0,0,.25); }
  `;
  (document.head || document.documentElement).appendChild(style);

  let toastTimer;
  function toast(message) {
    let el = document.getElementById('x2-toast');
    if (!el) { el = document.createElement('div'); el.id = 'x2-toast'; el.className = 'x2-toast'; document.body.appendChild(el); }
    el.textContent = message; el.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, 2400);
  }

  function apply() {
    if (!document.body) return;
    const logged = isLoggedIn();
    const login = !logged && isLoginScreen();

    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(el => {
      const hint = norm(el.getAttribute('placeholder'));
      const field = ((el.getAttribute('autocomplete') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + hint).toLowerCase();
      const isAccountField = /email|username|user name|phone|电子邮件|用户名/.test(field);
      el.classList.toggle('x2-hidden-placeholder', login && isAccountField);
    });

    document.querySelectorAll('button, [role="button"], a').forEach(el => {
      const t = norm(el.innerText || el.getAttribute('aria-label'));
      if (!t) return;
      const isGetApp = /^(get the app|get app|获取应用)$/i.test(t);
      if (!logged && isGetApp) {
        el.style.setProperty('visibility', 'hidden', 'important');
        el.style.setProperty('pointer-events', 'none', 'important');
      } else if (logged || !isGetApp) {
        el.style.removeProperty('visibility');
        el.style.removeProperty('pointer-events');
      }
    });
  }

  document.addEventListener('click', event => {
    if (isLoggedIn() || !isLoginScreen()) return;
    const el = event.target && event.target.closest ? event.target.closest('button, [role="button"], a') : null;
    if (!el) return;
    const text = norm(el.innerText || el.getAttribute('aria-label'));
    const thirdParty = /(使用\s*(手机|google|apple)\s*继续|continue\s*with\s*(phone|google|apple)|sign\s*in\s*with\s*(google|apple))/i.test(text);
    if (thirdParty) {
      event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
      toast(blockedMessage);
    }
  }, true);

  const observer = new MutationObserver(() => apply());
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['placeholder'] });
  let lastUrl = location.href;
  setInterval(() => { if (location.href !== lastUrl) { lastUrl = location.href; apply(); } }, 500);
  window.addEventListener('popstate', apply);
  window.addEventListener('pageshow', apply);
  apply();
})();
