package com.independent.xclient;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends ComponentActivity {
    private static final String HOME_URL = "https://x.com/";
    private FrameLayout root;
    private FrameLayout content;
    private WebView webView;
    private TextView offlineView;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private boolean online = true;
    private boolean pageLoadFailed = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(window, window.getDecorView());
        bars.setAppearanceLightStatusBars(true);
        bars.setAppearanceLightNavigationBars(true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        content = new FrameLayout(this);
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(content, contentParams);

        // Keep Web content out of status/navigation bars and display cutouts.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            androidx.core.graphics.Insets safe = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            content.setPadding(safe.left, safe.top, safe.right, safe.bottom);
            return insets;
        });

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setUserAgentString(webView.getSettings().getUserAgentString());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep X navigation in this app; external intents are not silently launched.
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageLoadFailed = false;
                showWeb();
            }
            @Override public void onPageFinished(WebView view, String url) {
                injectX2Controls();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    pageLoadFailed = true;
                    if (!hasNetwork()) showOffline();
                }
            }
        });
        content.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        offlineView = new TextView(this);
        offlineView.setText(isEnglish() ? "Network connection failed" : "网络连接失败");
        offlineView.setTextColor(Color.WHITE);
        offlineView.setTextSize(18);
        offlineView.setGravity(Gravity.CENTER);
        offlineView.setBackgroundColor(Color.BLACK);
        offlineView.setVisibility(View.GONE);
        content.addView(offlineView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        offlineView.setOnClickListener(v -> {
            if (hasNetwork()) {
                showWeb();
                webView.reload();
            }
        });

        online = hasNetwork();
        if (online) webView.loadUrl(HOME_URL); else showOffline();
        registerNetworkMonitor();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (offlineView.getVisibility() == View.VISIBLE) {
                    if (webView.canGoBack()) webView.goBack(); else finish();
                } else if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    finish();
                }
            }
        });
    }

    private void injectX2Controls() {
        if (webView == null) return;
        try (InputStream input = getAssets().open("x2-controls.js");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            String script = new String(output.toByteArray(), StandardCharsets.UTF_8);
            webView.evaluateJavascript(script, null);
        } catch (Exception ignored) {
            // The page remains usable if the optional UI controller cannot be loaded.
        }
    }

    private boolean isEnglish() {
        String language = getResources().getConfiguration().getLocales().get(0).getLanguage();
        return language != null && language.toLowerCase().startsWith("en");
    }

    private boolean hasNetwork() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network active = cm.getActiveNetwork();
        if (active == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(active);
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void showOffline() {
        offlineView.setText(isEnglish() ? "Network connection failed" : "网络连接失败");
        offlineView.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);
    }

    private void showWeb() {
        offlineView.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
    }

    private void registerNetworkMonitor() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                runOnUiThread(() -> {
                    boolean wasOffline = !online;
                    online = true;
                    if (wasOffline) {
                        showWeb();
                        webView.reload();
                    }
                });
            }
            @Override public void onLost(Network network) {
                runOnUiThread(() -> {
                    online = hasNetwork();
                    if (!online) showOffline();
                });
            }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                runOnUiThread(() -> {
                    boolean nowOnline = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                    if (nowOnline && !online) {
                        online = true;
                        showWeb();
                        webView.reload();
                    } else if (!nowOnline) {
                        online = false;
                        showOffline();
                    }
                });
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(networkCallback);
            } else {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build();
                connectivityManager.registerNetworkCallback(request, networkCallback);
            }
        } catch (Exception ignored) {
            // Older devices may not support the default callback API.
        }
    }

    @Override protected void onDestroy() {
        if (connectivityManager != null && networkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) {}
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
