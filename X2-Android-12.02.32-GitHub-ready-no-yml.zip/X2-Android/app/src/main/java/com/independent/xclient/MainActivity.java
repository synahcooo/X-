package com.independent.xclient;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewCompat;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private static final String HOME_URL = "https://x.com/?lang=zh-cn";
    // System insets already protect the status bar/cutout; keep only a 1dp extra reserve.
    private static final int EXTRA_TOP_DP = 1;
    private static final int EXTRA_BOTTOM_DP = 1;
    private static final long OFFLINE_PROBE_MS = 2200L;
    private static final long MAX_OFFLINE_PROBE_MS = 30000L;

    private FrameLayout root;
    private FrameLayout webSafeFrame;
    private WebView webView;
    private FrameLayout offlineView;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean online;
    private boolean offlinePageShown;
    private boolean pageLoadInProgress;
    private boolean mainFrameFailed;
    private boolean networkCallbackRegistered;
    private long lastBackPressed;
    private long lastAutoReloadAt;
    private long offlineRetryDelayMs = OFFLINE_PROBE_MS;
    private final Runnable saveScrollRunnable = this::saveRecentScroll;
    private float refreshTouchStartY;
    private boolean refreshStartedAtTop;
    private boolean restoreScrollPending = true;
    private static final String STATE_WEBVIEW = "x2_webview_state";
    private static final String PREFS = "x2_session_cache";
    private static final String PREF_URL = "last_url";
    private static final String PREF_SCROLL = "last_scroll_y";

    private final Runnable offlineProbe = new Runnable() {
        @Override public void run() {
            if (isFinishing() || offlineView == null || offlineView.getVisibility() != View.VISIBLE) return;
            if (hasValidatedNetwork()) {
                recoverNetwork();
            } else {
                scheduleNextOfflineProbe();
            }
        }
    };

    @Override
    protected void attachBaseContext(Context newBase) {
        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        Locale zh = Locale.SIMPLIFIED_CHINESE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(new android.os.LocaleList(zh));
        } else {
            config.locale = zh;
        }
        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureImmersiveWindow();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
        // Explicit edge-to-edge inset handling also covers Android 15+ enforcement,
        // display cutouts and gesture navigation. A separate fixed reserve is added below.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (view, windowInsets) -> {
            androidx.core.graphics.Insets bars = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            androidx.core.graphics.Insets ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        webSafeFrame = new FrameLayout(this);
        webSafeFrame.setBackgroundColor(Color.WHITE);
        webSafeFrame.setPadding(0, dp(EXTRA_TOP_DP), 0, dp(EXTRA_BOTTOM_DP));
        webSafeFrame.setClipToPadding(true);
        root.addView(webSafeFrame, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setStandardFontFamily("sans-serif");
        webView.getSettings().setSansSerifFontFamily("sans-serif");
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.getSettings().setCacheMode(hasValidatedNetwork() ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.setVisibility(View.INVISIBLE); // No first-frame flash before document-start controls run.
        webView.setOnScrollChangeListener((View v, int x, int y, int oldX, int oldY) -> {
            if (Math.abs(y - oldY) > dp(2)) {
                handler.removeCallbacks(saveScrollRunnable);
                handler.postDelayed(saveScrollRunnable, 650L);
            }
        });
        installDocumentStartControls();
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep X and its authentication flow inside this app's WebView.
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageLoadInProgress = true;
                mainFrameFailed = false;
                // Keep the native offline screen visible until this main-frame load succeeds.
                if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) {
                    view.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                Runnable finishPage = () -> {
                    pageLoadInProgress = false;
                    if (!mainFrameFailed) {
                        offlineRetryDelayMs = OFFLINE_PROBE_MS;
                        offlinePageShown = false;
                        showWeb();
                        rememberCurrentPage(url);
                        restoreRecentScroll();
                    } else {
                        showOffline();
                    }
                };
                if (url != null && (url.startsWith("https://x.com/") || url.equals("https://x.com")
                        || url.startsWith("https://twitter.com/"))) {
                    injectX2Controls(finishPage);
                } else {
                    handler.postDelayed(finishPage, 350L);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    pageLoadInProgress = false;
                    mainFrameFailed = true;
                    offlinePageShown = true;
                    showOffline();
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                            android.webkit.WebResourceResponse response) {
                if (request != null && request.isForMainFrame() && response != null
                        && response.getStatusCode() >= 400) {
                    pageLoadInProgress = false;
                    mainFrameFailed = true;
                    showOffline();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, android.webkit.SslErrorHandler handler,
                                           android.net.http.SslError error) {
                handler.cancel();
                if (error != null && error.getUrl() != null && error.getUrl().contains("x.com")) {
                    pageLoadInProgress = false;
                    mainFrameFailed = true;
                    showOffline();
                }
            }
        });
        webSafeFrame.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        // Pull down while already at the top to manually refresh, without adding a permanent toolbar.
        webView.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                refreshTouchStartY = event.getY();
                refreshStartedAtTop = webView.getScrollY() <= dp(2);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                float distance = event.getY() - refreshTouchStartY;
                if (refreshStartedAtTop && distance > dp(115) && webView.getScrollY() <= dp(2)) {
                    refreshPage();
                }
            }
            return false;
        });

        createOfflineView();

        online = hasValidatedNetwork();
        boolean restored = false;
        if (savedInstanceState != null && savedInstanceState.containsKey(STATE_WEBVIEW)) {
            try {
                Bundle webState = savedInstanceState.getBundle(STATE_WEBVIEW);
                restored = webState != null && webView.restoreState(webState) != null;
            } catch (Exception ignored) { }
        }
        if (restored) {
            pageLoadInProgress = true;
            webView.setVisibility(View.INVISIBLE);
        } else {
            loadHome();
        }
        registerNetworkMonitor();
        installBackHandling();
        applySafeAreaAgain();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable roundedBackground(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private TextView offlineLabel(String text, int size, int color) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(size);
        label.setTextColor(color);
        label.setGravity(Gravity.CENTER);
        label.setFontFeatureSettings("kern");
        return label;
    }

    private void createOfflineView() {
        offlineView = new FrameLayout(this);
        offlineView.setBackgroundColor(Color.WHITE);
        offlineView.setVisibility(View.GONE);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        page.setPadding(dp(24), dp(18), dp(24), dp(4));
        offlineView.addView(page, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView logo = offlineLabel("X", 34, Color.BLACK);
        logo.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        page.addView(logo, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        page.addView(center, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView symbol = offlineLabel("⌁", 54, Color.rgb(83, 100, 113));
        center.addView(symbol, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(76)));
        TextView title = offlineLabel("网络连接失败", 20, Color.rgb(15, 20, 25));
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = dp(12);
        center.addView(title, titleParams);
        TextView subtitle = offlineLabel("请检查网络连接，然后重试", 14, Color.rgb(83, 100, 113));
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subtitleParams.topMargin = dp(8);
        center.addView(subtitle, subtitleParams);

        Button retry = new Button(this);
        retry.setText("重试");
        retry.setTextColor(Color.WHITE);
        retry.setTextSize(15);
        retry.setAllCaps(false);
        retry.setMinWidth(dp(132));
        retry.setMinHeight(dp(46));
        retry.setBackground(roundedBackground(Color.rgb(29, 155, 240), 24));
        retry.setOnClickListener(v -> retryIfOnline());
        LinearLayout.LayoutParams retryParams = new LinearLayout.LayoutParams(dp(148), dp(48));
        retryParams.gravity = Gravity.CENTER_HORIZONTAL;
        retryParams.topMargin = dp(24);
        center.addView(retry, retryParams);

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(0, dp(8), 0, dp(8));
        nav.setBackground(roundedBackground(Color.rgb(247, 249, 250), 18));
        page.addView(nav, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));
        addOfflineNavItem(nav, "⌂", "主页", "https://x.com/home");
        addOfflineNavItem(nav, "⌕", "搜索", "https://x.com/explore");
        addOfflineNavItem(nav, "♧", "通知", "https://x.com/notifications");

        offlineView.setContentDescription("网络连接失败");
        root.addView(offlineView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private void addOfflineNavItem(LinearLayout nav, String glyph, String label, String url) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        TextView icon = offlineLabel(glyph, 21, Color.rgb(83, 100, 113));
        TextView caption = offlineLabel(label, 11, Color.rgb(83, 100, 113));
        item.addView(icon, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(27)));
        item.addView(caption, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(18)));
        item.setOnClickListener(v -> navigateFromOffline(url));
        nav.addView(item, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
    }

    private void navigateFromOffline(String url) {
        if (!hasValidatedNetwork()) {
            retryIfOnline();
            return;
        }
        if (webView == null) return;
        restoreScrollPending = true;
        mainFrameFailed = false;
        pageLoadInProgress = true;
        webView.setVisibility(View.INVISIBLE);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.loadUrl(url);
    }

    private void configureImmersiveWindow() {
        Window window = getWindow();
        // Draw edge-to-edge only at the window layer; the root consumes system insets,
        // then webSafeFrame adds an additional fixed safety reserve.
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        androidx.core.view.WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(window, window.getDecorView());
        if (controller != null) {
            controller.setAppearanceLightStatusBars(true);
            controller.setAppearanceLightNavigationBars(true);
        }
    }

    private void applySafeAreaAgain() {
        if (webSafeFrame == null) return;
        // Explicitly re-apply after window/insets changes; never depend on a single status-bar query.
        webSafeFrame.setPadding(0, dp(EXTRA_TOP_DP), 0, dp(EXTRA_BOTTOM_DP));
        webSafeFrame.setClipToPadding(true);
        if (root != null) androidx.core.view.ViewCompat.requestApplyInsets(root);
    }

    private void loadHome() {
        if (webView == null) return;
        pageLoadInProgress = true;
        mainFrameFailed = false;
        webView.setVisibility(View.INVISIBLE);
        boolean connected = hasValidatedNetwork();
        webView.getSettings().setCacheMode(connected ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", "zh-CN,zh-Hans;q=0.95,zh;q=0.9,en;q=0.7");
        String lastUrl = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_URL, HOME_URL);
        if (lastUrl == null || !(lastUrl.startsWith("https://x.com/") || lastUrl.equals("https://x.com"))) lastUrl = HOME_URL;
        webView.loadUrl(lastUrl, headers);
    }

    private void rememberCurrentPage(String url) {
        if (url == null || !(url.startsWith("https://x.com/") || url.equals("https://x.com"))) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_URL, url).apply();
    }

    private void restoreRecentScroll() {
        if (!restoreScrollPending || webView == null) return;
        restoreScrollPending = false;
        int y = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(PREF_SCROLL, 0);
        if (y > 0) {
            final int savedY = y;
            handler.postDelayed(() -> {
                if (webView != null && !isFinishing()) {
                    webView.evaluateJavascript("try{window.scrollTo(0," + savedY + ");}catch(e){}", null);
                }
            }, 450L);
        }
    }

    private void saveRecentScroll() {
        if (webView == null || isFinishing()) return;
        webView.evaluateJavascript("String(Math.max(0,Math.round(window.scrollY||document.documentElement.scrollTop||0)))", value -> {
            try {
                int y = Integer.parseInt(value == null ? "0" : value.replaceAll("[^0-9]", ""));
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(PREF_SCROLL, y).apply();
            } catch (Exception ignored) { }
        });
        if (!offlinePageShown && !mainFrameFailed && !pageLoadInProgress) rememberCurrentPage(webView.getUrl());
    }

    private void refreshPage() {
        if (webView == null) return;
        if (!hasValidatedNetwork()) {
            Toast.makeText(this, "网络连接失败", Toast.LENGTH_SHORT).show();
            return;
        }
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        pageLoadInProgress = true;
        mainFrameFailed = false;
        webView.reload();
    }

    private String readAsset(String name) throws Exception {
        try (InputStream input = getAssets().open(name);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String buildControlScript() throws Exception {
        String script = readAsset("x2-controls.js");
        String dictionary = readAsset("i18n/zh-CN.json");
        // The dictionary is shipped inside the APK and injected locally: no first-run network dependency.
        JSONObject parsed = new JSONObject(dictionary);
        return "window.__X2_ZH_DICT__=" + parsed.toString() + ";\n" + script;
    }

    private void installDocumentStartControls() {
        if (webView == null) return;
        try {
            String script = buildControlScript();
            WebViewCompat.addDocumentStartJavaScript(webView, script,
                    Collections.singleton("https://x.com/*"));
        } catch (Exception ignored) {
            // The native visibility gate and onPageFinished injection remain independent fallbacks.
        }
    }

    private void injectX2Controls(Runnable afterInjection) {
        if (webView == null || isFinishing()) return;
        try {
            webView.evaluateJavascript(buildControlScript(), result -> {
                if (afterInjection != null && !isFinishing()) handler.postDelayed(afterInjection, 350L);
            });
        } catch (Exception ignored) {
            if (afterInjection != null) handler.postDelayed(afterInjection, 350L);
        }
    }

    private boolean hasValidatedNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network active = cm.getActiveNetwork();
                if (active == null) return false;
                NetworkCapabilities caps = cm.getNetworkCapabilities(active);
                return caps != null
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            }
            android.net.NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception ignored) {
            return false;
        }
    }

    private void showOffline() {
        if (offlineView == null) return;
        offlinePageShown = true;
        online = false;
        pageLoadInProgress = false;
        offlineView.setVisibility(View.VISIBLE);
        if (webView != null) webView.setVisibility(View.GONE);
        scheduleNextOfflineProbe();
    }

    private void scheduleNextOfflineProbe() {
        handler.removeCallbacks(offlineProbe);
        long delay = offlineRetryDelayMs;
        handler.postDelayed(offlineProbe, delay);
        offlineRetryDelayMs = Math.min(MAX_OFFLINE_PROBE_MS, offlineRetryDelayMs * 2L);
    }

    private void showWeb() {
        offlineRetryDelayMs = OFFLINE_PROBE_MS;
        if (offlineView != null) offlineView.setVisibility(View.GONE);
        if (webView != null) webView.setVisibility(View.VISIBLE);
        offlinePageShown = false;
        handler.removeCallbacks(offlineProbe);
    }

    private void retryIfOnline() {
        if (hasValidatedNetwork()) {
            recoverNetwork();
        } else {
            showOffline();
        }
    }

    private void recoverNetwork() {
        if (webView == null || isFinishing()) return;
        long now = System.currentTimeMillis();
        // Do not restart an already-running recovery load when several network callbacks arrive.
        if (pageLoadInProgress && offlinePageShown) return;
        // Debounce duplicate callbacks from onAvailable/onCapabilitiesChanged/polling.
        if (now - lastAutoReloadAt < 1800L && pageLoadInProgress) return;
        handler.removeCallbacks(offlineProbe);
        lastAutoReloadAt = now;
        online = true;
        // Keep the offline screen in front until onPageFinished confirms a successful load.
        offlinePageShown = true;
        pageLoadInProgress = true;
        mainFrameFailed = false;
        webView.setVisibility(View.INVISIBLE);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        if (webView.getUrl() == null || webView.getUrl().isEmpty()) loadHome();
        else webView.reload();
    }

    private void registerNetworkMonitor() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                handler.postDelayed(() -> {
                    if (hasValidatedNetwork() && offlineView != null
                            && (offlineView.getVisibility() == View.VISIBLE || offlinePageShown)) recoverNetwork();
                }, 900L);
            }
            @Override public void onLost(Network network) {
                handler.post(() -> {
                    // Do not replace the WebView while it is trying to restore cached content.
                });
            }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                handler.post(() -> {
                    if (hasValidatedNetwork()) {
                        if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) recoverNetwork();
                    }
                    // Keep the last rendered feed visible during a temporary outage; the
                    // cache/offline screen is used only if a main-frame load actually fails.
                });
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(networkCallback);
            } else {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
                connectivityManager.registerNetworkCallback(request, networkCallback);
            }
            networkCallbackRegistered = true;
        } catch (Exception ignored) {
            networkCallbackRegistered = false;
            // The offline polling loop and onResume checks still work without callbacks.
        }
    }

    private void installBackHandling() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                // Android normally lets the IME consume Back first; this is an explicit second check.
                if (isKeyboardVisible()) {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                    setEnabled(true);
                    return;
                }
                if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) {
                    retryIfOnline();
                    return;
                }
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastBackPressed < 2000L) finish();
                else {
                    lastBackPressed = now;
                    Toast.makeText(MainActivity.this, "再按一次返回键退出", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isKeyboardVisible() {
        try {
            return WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()) != null
                    && androidx.core.view.ViewCompat.getRootWindowInsets(getWindow().getDecorView()) != null
                    && androidx.core.view.ViewCompat.getRootWindowInsets(getWindow().getDecorView())
                    .isVisible(WindowInsetsCompat.Type.ime());
        } catch (Exception ignored) {
            return false;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) {
            try {
                Bundle webState = new Bundle();
                webView.saveState(webState);
                outState.putBundle(STATE_WEBVIEW, webState);
            } catch (Exception ignored) { }
            saveRecentScroll();
        }
        super.onSaveInstanceState(outState);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(saveScrollRunnable);
        saveRecentScroll();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        configureImmersiveWindow();
        applySafeAreaAgain();
        if (webView != null && hasValidatedNetwork()
                && offlineView != null && offlineView.getVisibility() == View.VISIBLE) recoverNetwork();
        else if (webView != null && !hasValidatedNetwork() && webView.getUrl() != null) {
            webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (connectivityManager != null && networkCallback != null && networkCallbackRegistered) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) { }
        }
        handler.removeCallbacks(saveScrollRunnable);
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
