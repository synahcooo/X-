(() => {
  'use strict';
  if (window.__x2ControlsInstalled) return;
  window.__x2ControlsInstalled = true;

  const norm = value => String(value || '').replace(/\s+/g, ' ').trim();
  const messages = {
    phone: '您的手机号码不支持',
    google: '该设备谷歌服务异常',
    apple: '不支持非apple系统'
  };
  const overlayPrefix = 'x2-hit-';
  const overlays = new Map();
  let toastTimer = 0;
  let lastUrl = location.href;
  let applyQueued = false;

  const style = document.createElement('style');
  style.id = 'x2-controls-style';
  style.textContent = `
    .x2-hidden-placeholder::placeholder { color: transparent !important; opacity: 0 !important; }
    .x2-hit-overlay { position: fixed !important; z-index: 2147483646 !important; display: block !important; margin: 0 !important; padding: 0 !important; border: 0 !important; border-radius: 0 !important; opacity: 0 !important; pointer-events: auto !important; touch-action: manipulation !important; cursor: pointer !important; }
    .x2-hit-cover { position: fixed !important; z-index: 2147483645 !important; display: block !important; margin: 0 !important; padding: 0 !important; border: 0 !important; pointer-events: auto !important; }
    .x2-toast { position: fixed !important; z-index: 2147483647 !important; left: 50% !important; bottom: max(28px, env(safe-area-inset-bottom)) !important; transform: translateX(-50%) !important; max-width: calc(100vw - 40px) !important; padding: 12px 18px !important; border-radius: 12px !important; background: rgba(25,25,25,.96) !important; color: #fff !important; font: 14px/1.45 sans-serif !important; text-align: center !important; box-shadow: 0 4px 18px rgba(0,0,0,.25) !important; }
  `;
  (document.head || document.documentElement).appendChild(style);

  function toast(message) {
    if (!document.body) return;
    let node = document.getElementById('x2-toast');
    if (!node) {
      node = document.createElement('div');
      node.id = 'x2-toast';
      node.className = 'x2-toast';
      node.setAttribute('role', 'status');
      document.body.appendChild(node);
    }
    node.textContent = message;
    node.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { if (node.isConnected) node.hidden = true; }, 2300);
  }

  function buttonText(el) {
    return norm(el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title'));
  }

  function isLoginScreen() {
    if (/\/(i\/flow\/login|login|account\/access)(\/|$)/i.test(location.pathname)) return true;
    return !!document.querySelector('input[autocomplete*="username" i], input[name*="text" i], input[placeholder*="email" i], input[placeholder*="用户名"], input[placeholder*="电子邮箱"]');
  }

  function isLoggedIn() {
    if (/^\/i\/flow\/login|^\/login/i.test(location.pathname)) return false;
    return location.pathname === '/home' || location.pathname.startsWith('/home/') ||
      !!document.querySelector('[data-testid="AppTabBar_Home_Link"], [data-testid="SideNav_AccountSwitcher_Button"], [data-testid="AppTabBar_Profile_Link"], nav[aria-label="Primary"]');
  }

  function thirdPartyKind(el) {
    const text = buttonText(el).toLowerCase();
    const aria = norm(el.getAttribute('aria-label')).toLowerCase();
    const combined = `${text} ${aria}`;
    if (/(使用\s*手机\s*继续|continue\s*with\s*phone|phone\s*number)/i.test(combined)) return 'phone';
    if (/(使用\s*google\s*继续|continue\s*with\s*google|sign\s*in\s*with\s*google)/i.test(combined)) return 'google';
    if (/(使用\s*apple\s*继续|continue\s*with\s*apple|sign\s*in\s*with\s*apple)/i.test(combined)) return 'apple';
    return null;
  }

  function candidateButtons() {
    return Array.from(document.querySelectorAll('button, [role="button"], a, [tabindex="0"]'));
  }

  function rectStyle(overlay, rect) {
    overlay.style.left = `${Math.max(0, rect.left)}px`;
    overlay.style.top = `${Math.max(0, rect.top)}px`;
    overlay.style.width = `${Math.max(0, rect.width)}px`;
    overlay.style.height = `${Math.max(0, rect.height)}px`;
  }

  function getOverlay(target, key, className) {
    let overlay = overlays.get(target);
    if (!overlay || !overlay.isConnected || overlay.dataset.x2Overlay !== key) {
      if (overlay && overlay.isConnected) overlay.remove();
      overlay = document.createElement('div');
      overlay.className = className;
      overlay.dataset.x2Overlay = key;
      overlay.setAttribute('aria-hidden', 'true');
      overlay.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        if (key.startsWith('third:')) toast(messages[key.slice(6)]);
      }, true);
      overlay.addEventListener('pointerdown', event => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
      }, true);
      document.body.appendChild(overlay);
      overlays.set(target, overlay);
    }
    return overlay;
  }

  function nearestBackground(el) {
    let node = el;
    while (node && node !== document.documentElement) {
      const color = getComputedStyle(node).backgroundColor;
      if (color && color !== 'rgba(0, 0, 0, 0)' && color !== 'transparent') return color;
      node = node.parentElement;
    }
    return getComputedStyle(document.body).backgroundColor || '#fff';
  }

  function cleanOverlays(keep) {
    for (const [target, overlay] of overlays.entries()) {
      if (!keep.has(target) || !target.isConnected) {
        overlay.remove();
        overlays.delete(target);
      }
    }
  }

  function autoTranslateVisiblePosts() {
    // Use X's own per-post translation control when it is offered by X.
    // This avoids sending private content to an unrelated translation provider.
    const controls = Array.from(document.querySelectorAll('button, [role="button"]'));
    controls.forEach(control => {
      if (control.dataset.x2AutoTranslated === '1') return;
      const label = `${buttonText(control)} ${control.getAttribute('aria-label') || ''} ${control.getAttribute('title') || ''}`.toLowerCase();
      if (!/(translate post|translate this post|翻译帖子|翻译此帖子)/i.test(label)) return;
      const rect = control.getBoundingClientRect();
      if (rect.width < 4 || rect.height < 4 || rect.bottom < 0 || rect.top > innerHeight) return;
      control.dataset.x2AutoTranslated = '1';
      control.click();
    });
  }

  function apply() {
    applyQueued = false;
    if (!document.body) return;
    const logged = isLoggedIn();
    const login = !logged && isLoginScreen();

    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(input => {
      const signature = `${input.getAttribute('autocomplete') || ''} ${input.getAttribute('name') || ''} ${input.getAttribute('placeholder') || ''}`.toLowerCase();
      const accountInput = /(email|username|user name|电子邮箱|电子邮件|用户名)/i.test(signature);
      input.classList.toggle('x2-hidden-placeholder', login && accountInput);
    });

    const keep = new Set();
    if (login) {
      candidateButtons().forEach(el => {
        const kind = thirdPartyKind(el);
        if (!kind) return;
        const rect = el.getBoundingClientRect();
        if (rect.width < 8 || rect.height < 8 || rect.bottom < 0 || rect.top > innerHeight) return;
        const overlay = getOverlay(el, `third:${kind}`, 'x2-hit-overlay');
        rectStyle(overlay, rect);
        keep.add(el);
      });
    }

    // The home-page Get App control is concealed by a background-colored cover,
    // rather than by changing or deleting the original control.
    if (!logged && !login) {
      candidateButtons().forEach(el => {
        const text = buttonText(el);
        if (!/^(get the app|get app|获取应用)$/i.test(text)) return;
        const rect = el.getBoundingClientRect();
        if (rect.width < 5 || rect.height < 5) return;
        const cover = getOverlay(el, 'get-app-cover', 'x2-hit-cover');
        rectStyle(cover, rect);
        cover.style.background = nearestBackground(el);
        keep.add(el);
      });
    }
    cleanOverlays(keep);
    if (logged) autoTranslateVisiblePosts();
  }

  function scheduleApply() {
    if (applyQueued) return;
    applyQueued = true;
    requestAnimationFrame(apply);
  }

  // Capture-phase fallback protects against page handlers and synthetic bubbling.
  document.addEventListener('click', event => {
    if (isLoggedIn() || !isLoginScreen()) return;
    const el = event.target && event.target.closest ? event.target.closest('button, [role="button"], a, [tabindex="0"]') : null;
    if (!el) return;
    const kind = thirdPartyKind(el);
    if (!kind) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    toast(messages[kind]);
  }, true);

  const observer = new MutationObserver(scheduleApply);
  observer.observe(document.documentElement, {
    childList: true, subtree: true, attributes: true,
    attributeFilter: ['placeholder', 'aria-label', 'href', 'class', 'style']
  });
  window.addEventListener('resize', scheduleApply, { passive: true });
  window.addEventListener('scroll', scheduleApply, { passive: true, capture: true });
  window.addEventListener('popstate', scheduleApply);
  window.addEventListener('pageshow', scheduleApply);
  window.addEventListener('hashchange', scheduleApply);
  setInterval(() => {
    if (location.href !== lastUrl) lastUrl = location.href;
    scheduleApply();
  }, 450);
  scheduleApply();
})();
