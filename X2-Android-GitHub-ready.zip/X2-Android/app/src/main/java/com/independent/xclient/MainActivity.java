package com.independent.xclient;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private static final String HOME_URL = "https://x.com/?lang=zh-cn";
    private FrameLayout root;
    private WebView webView;
    private TextView offlineView;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean online;
    private boolean offlinePageShown;
    private long lastBackPressed;

    @Override
    protected void attachBaseContext(Context newBase) {
        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        Locale zh = Locale.SIMPLIFIED_CHINESE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(new android.os.LocaleList(zh));
        } else {
            config.locale = zh;
        }
        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureImmersiveWindow();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setStandardFontFamily("sans-serif");
        webView.getSettings().setSansSerifFontFamily("sans-serif");
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep X and its authentication flow inside this app's WebView.
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (hasValidatedNetwork()) {
                    offlinePageShown = false;
                    showWeb();
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                injectX2Controls();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    offlinePageShown = true;
                    showOffline();
                }
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        offlineView = new TextView(this);
        offlineView.setText("网络连接失败");
        offlineView.setTextColor(Color.WHITE);
        offlineView.setTextSize(18);
        offlineView.setGravity(Gravity.CENTER);
        offlineView.setBackgroundColor(Color.BLACK);
        offlineView.setVisibility(View.GONE);
        root.addView(offlineView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        offlineView.setOnClickListener(v -> retryIfOnline());

        online = hasValidatedNetwork();
        if (online) loadHome(); else showOffline();
        registerNetworkMonitor();
        installBackHandling();
    }

    private void configureImmersiveWindow() {
        Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
        if (controller != null) {
            controller.hide(WindowInsetsCompat.Type.statusBars() | WindowInsetsCompat.Type.navigationBars());
            controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }

    private void loadHome() {
        if (webView != null) webView.loadUrl(HOME_URL);
    }

    private void injectX2Controls() {
        if (webView == null || isFinishing()) return;
        try (InputStream input = getAssets().open("x2-controls.js");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            webView.evaluateJavascript(new String(output.toByteArray(), StandardCharsets.UTF_8), null);
        } catch (Exception ignored) {
            // Keep the official site usable if the optional controller cannot be injected.
        }
    }

    private boolean hasValidatedNetwork() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network active = cm.getActiveNetwork();
        if (active == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(active);
        return caps != null
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                    || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));
    }

    private void showOffline() {
        if (offlineView == null) return;
        offlineView.setText("网络连接失败");
        offlineView.setVisibility(View.VISIBLE);
        if (webView != null) webView.setVisibility(View.GONE);
    }

    private void showWeb() {
        if (offlineView != null) offlineView.setVisibility(View.GONE);
        if (webView != null) webView.setVisibility(View.VISIBLE);
    }

    private void retryIfOnline() {
        if (hasValidatedNetwork() && webView != null) {
            online = true;
            offlinePageShown = false;
            showWeb();
            webView.reload();
        }
    }

    private void registerNetworkMonitor() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                handler.post(() -> refreshNetworkState(true));
            }
            @Override public void onLost(Network network) {
                handler.post(() -> refreshNetworkState(hasValidatedNetwork()));
            }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                handler.post(() -> refreshNetworkState(
                        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                            || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))));
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(networkCallback);
            } else {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
                connectivityManager.registerNetworkCallback(request, networkCallback);
            }
        } catch (Exception ignored) {
            // onResume also rechecks connectivity if callback registration is unavailable.
        }
    }

    private void refreshNetworkState(boolean callbackSuggestsOnline) {
        boolean nowOnline = callbackSuggestsOnline && hasValidatedNetwork();
        boolean wasOnline = online;
        online = nowOnline;
        if (!nowOnline) {
            showOffline();
        } else if (!wasOnline || offlinePageShown || offlineView.getVisibility() == View.VISIBLE) {
            offlinePageShown = false;
            showWeb();
            if (webView != null) webView.reload();
        }
    }

    private void installBackHandling() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) {
                    if (hasValidatedNetwork()) retryIfOnline();
                    else Toast.makeText(MainActivity.this, "网络连接失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastBackPressed < 2000) {
                    finish();
                } else {
                    lastBackPressed = now;
                    Toast.makeText(MainActivity.this, "再按一次返回键退出", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null && hasValidatedNetwork() && offlineView != null
                && offlineView.getVisibility() == View.VISIBLE) retryIfOnline();
        configureImmersiveWindow();
    }

    @Override protected void onDestroy() {
        if (connectivityManager != null && networkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) { }
        }
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
