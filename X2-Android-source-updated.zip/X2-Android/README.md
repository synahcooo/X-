# X₂ Android

独立 Android 应用工程：显示名称 `X₂`，包名 `com.independent.xclient`，主站 `https://x.com/`。

## 已实现内容
- 原生 Android Activity + WebView，加载 X 官方网站；不伪装成 X 官方客户端。
- 沉浸式全屏显示，默认隐藏状态栏和导航栏，可通过边缘滑动临时呼出系统栏。
- 系统返回键优先返回 WebView 页面历史；没有历史时退出应用。
- 断网时显示全屏黑底“网络连接失败”；网络恢复后自动刷新。
- 使用提供的 X 图标素材生成 mdpi 至 xxxhdpi 启动器图标。
- `x2-controls.js`：动态监听页面 DOM/路由；未登录页用与页面背景同色的遮罩覆盖“获取应用”；登录页隐藏邮箱/用户名输入框的 placeholder（不禁用输入）；在手机、Google、Apple 第三方登录入口上方放置透明拦截遮罩，点击分别显示指定提示，且不触发底层登录入口；官方邮箱/用户名输入和“继续”按钮不拦截。检测到已登录主界面后解除限制，退出登录回到登录页后重新启用。

## 构建环境
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- compileSdk 35 / targetSdk 35 / minSdk 23
- Debug 包名：`com.independent.xclient`

ZIP 未携带 Gradle Wrapper JAR。GitHub Actions 会优先使用完整 Wrapper；当前包不完整时使用 Gradle 8.9 回退，不会自动升级 AGP/Gradle。构建工作流在 `.github/workflows/build.yml`。

## GitHub 手机端构建
1. 新建空 GitHub 仓库。
2. 解压本 ZIP，把 `X2-Android` 文件夹内的**全部内容**上传到仓库根目录（包括隐藏的 `.github` 文件夹）。也可以把本 ZIP 上传到仓库根目录，再在 Actions 手动运行并留空 `source_zip`。
3. 打开仓库 **Actions → Build Android APK → Run workflow**。
4. 等待任务结束；成功后打开运行记录底部 **Artifacts → X2-Android-APK** 下载 APK。

## 验证状态与限制
源码已进行 Java/JavaScript 基础静态检查；本执行环境无法访问 Gradle 分发服务器，且未安装本项目所需的 Gradle，因此这里没有完成 Android APK 编译，也没有真实设备运行验证。请以 GitHub Actions 的实际构建结果为准。X 网站是动态网页，登录页 DOM 可能变化；如 X 更新按钮文案或结构，需按新页面调整选择器。第三方入口提示不会伪造 Google、Apple 或手机号服务故障。
