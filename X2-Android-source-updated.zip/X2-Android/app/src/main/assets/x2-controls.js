(() => {
  'use strict';
  if (window.__x2ControlsInstalled) return;
  window.__x2ControlsInstalled = true;

  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const messages = {
    phone: '您的手机号码不支持',
    google: '该设备谷歌服务异常',
    apple: '不支持非apple系统'
  };

  const isLoggedIn = () => {
    const p = location.pathname;
    if (/^\/(i\/flow\/login|login|account\/access)/i.test(p)) return false;
    return p === '/home' || p.startsWith('/home/') ||
      !!document.querySelector('[data-testid="AppTabBar_Home_Link"], nav[aria-label="Primary"], [data-testid="SideNav_AccountSwitcher_Button"]');
  };
  const isLoginScreen = () => /\/(i\/flow\/login|login)(\/|$)/i.test(location.pathname) ||
    !!Array.from(document.querySelectorAll('input')).find(el =>
      /email|username|phone|电子邮件|用户名/i.test(
        (el.getAttribute('autocomplete') || '') + ' ' +
        (el.getAttribute('name') || '') + ' ' +
        (el.getAttribute('placeholder') || '')
      )
    );

  const style = document.createElement('style');
  style.id = 'x2-controls-style';
  style.textContent = `
    html, body, button, input, textarea, select {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Roboto",
        "Noto Sans CJK SC", sans-serif !important;
    }
    .x2-hidden-placeholder::placeholder {
      color: transparent !important;
      opacity: 0 !important;
    }
    .x2-mask {
      position: fixed !important;
      display: block !important;
      z-index: 2147483647 !important;
      margin: 0 !important;
      padding: 0 !important;
      border: 0 !important;
      box-sizing: border-box !important;
      pointer-events: auto !important;
      touch-action: manipulation !important;
      cursor: default !important;
    }
    .x2-toast {
      position: fixed;
      z-index: 2147483647;
      left: 50%;
      bottom: max(28px, env(safe-area-inset-bottom));
      transform: translateX(-50%);
      max-width: calc(100vw - 40px);
      padding: 12px 18px;
      border-radius: 12px;
      background: rgba(25,25,25,.96);
      color: #fff;
      font: 14px/1.45 system-ui, sans-serif;
      text-align: center;
      box-shadow: 0 4px 18px rgba(0,0,0,.25);
    }`;
  (document.head || document.documentElement).appendChild(style);

  let toastTimer;
  function toast(message) {
    let el = document.getElementById('x2-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'x2-toast';
      el.className = 'x2-toast';
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2400);
  }

  const masks = new Map();
  const originalControlState = new WeakMap();
  function disableUnderlyingControl(el) {
    if (!originalControlState.has(el)) {
      originalControlState.set(el, {
        pointerEvents: el.style.pointerEvents,
        tabIndex: el.getAttribute('tabindex'),
        ariaDisabled: el.getAttribute('aria-disabled')
      });
    }
    el.style.setProperty('pointer-events', 'none', 'important');
    el.setAttribute('tabindex', '-1');
    el.setAttribute('aria-disabled', 'true');
  }
  function restoreUnderlyingControl(el) {
    const old = originalControlState.get(el);
    if (!old) return;
    if (old.pointerEvents) el.style.pointerEvents = old.pointerEvents;
    else el.style.removeProperty('pointer-events');
    if (old.tabIndex === null) el.removeAttribute('tabindex');
    else el.setAttribute('tabindex', old.tabIndex);
    if (old.ariaDisabled === null) el.removeAttribute('aria-disabled');
    else el.setAttribute('aria-disabled', old.ariaDisabled);
    originalControlState.delete(el);
  }
  function backgroundColorFor(el) {
    let node = el.parentElement;
    while (node && node !== document.documentElement) {
      const color = getComputedStyle(node).backgroundColor;
      if (color && color !== 'transparent' && color !== 'rgba(0, 0, 0, 0)') return color;
      node = node.parentElement;
    }
    return getComputedStyle(document.body).backgroundColor || '#fff';
  }
  function classify(el) {
    const text = norm(el.innerText || el.getAttribute('aria-label') || el.getAttribute('title'));
    if (/^(get the app|get app|获取应用)$/i.test(text)) return { type: 'getapp' };
    if (/(使用\s*手机\s*继续|continue\s*with\s*phone|sign\s*in\s*with\s*phone)/i.test(text)) return { type: 'phone' };
    if (/(使用\s*google\s*继续|continue\s*with\s*google|sign\s*in\s*with\s*google)/i.test(text)) return { type: 'google' };
    if (/(使用\s*apple\s*继续|continue\s*with\s*apple|sign\s*in\s*with\s*apple)/i.test(text)) return { type: 'apple' };
    return null;
  }
  function removeMask(el) {
    const mask = masks.get(el);
    if (mask) mask.remove();
    masks.delete(el);
  }
  function placeMask(el, mask, type) {
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height || !el.isConnected) {
      mask.style.display = 'none';
      return;
    }
    mask.style.display = 'block';
    mask.style.left = rect.left + 'px';
    mask.style.top = rect.top + 'px';
    mask.style.width = rect.width + 'px';
    mask.style.height = rect.height + 'px';
    mask.style.borderRadius = getComputedStyle(el).borderRadius || '0';
    mask.style.background = type === 'getapp' ? backgroundColorFor(el) : 'transparent';
  }

  function apply() {
    if (!document.body) return;
    if (document.documentElement && document.documentElement.lang !== 'zh-CN') {
      document.documentElement.lang = 'zh-CN';
    }
    const logged = isLoggedIn();
    const login = !logged && isLoginScreen();

    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(el => {
      const field = ((el.getAttribute('autocomplete') || '') + ' ' +
        (el.getAttribute('name') || '') + ' ' +
        (el.getAttribute('placeholder') || '')).toLowerCase();
      const accountField = /email|username|user name|phone|电子邮件|用户名/.test(field);
      el.classList.toggle('x2-hidden-placeholder', login && accountField);
    });

    const active = new Set();
    document.querySelectorAll('button, [role="button"], a').forEach(el => {
      const kind = classify(el);
      const shouldMask = !logged && kind && (kind.type === 'getapp' || (login && kind.type !== 'getapp'));
      if (!shouldMask) return;
      active.add(el);
      disableUnderlyingControl(el);
      let mask = masks.get(el);
      if (!mask) {
        mask = document.createElement('div');
        mask.className = 'x2-mask';
        mask.setAttribute('aria-hidden', 'true');
        mask.addEventListener('pointerdown', e => {
          e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        }, true);
        mask.addEventListener('click', e => {
          e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
          const item = masks.get(el);
          if (!item || isLoggedIn()) return;
          const type = item.dataset.x2Type;
          if (type && messages[type]) toast(messages[type]);
        }, true);
        document.body.appendChild(mask);
        masks.set(el, mask);
      }
      mask.dataset.x2Type = kind.type;
      placeMask(el, mask, kind.type);
    });

    for (const [el, mask] of masks.entries()) {
      if (!active.has(el) || !el.isConnected) {
        mask.remove();
        masks.delete(el);
        if (el.isConnected) restoreUnderlyingControl(el);
      } else {
        const kind = classify(el);
        if (kind) placeMask(el, mask, kind.type);
      }
    }
  }

  const observer = new MutationObserver(apply);
  observer.observe(document.documentElement, {
    childList: true, subtree: true, attributes: true,
    attributeFilter: ['placeholder', 'aria-label', 'title']
  });
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) lastUrl = location.href;
    apply();
  }, 350);
  window.addEventListener('resize', apply, { passive: true });
  window.addEventListener('scroll', apply, true);
  window.addEventListener('popstate', apply);
  window.addEventListener('pageshow', apply);
  apply();
})();