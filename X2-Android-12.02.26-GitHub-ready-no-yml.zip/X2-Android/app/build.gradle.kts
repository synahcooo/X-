plugins {
    id("com.android.application")
}

android {
    namespace = "com.independent.xclient"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.independent.xclient"
        minSdk = 23
        targetSdk = 35
        versionCode = 120226
        versionName = "12.02.26"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            // Keep the confirmed applicationId identical in the debug APK.
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.activity:activity:1.10.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
