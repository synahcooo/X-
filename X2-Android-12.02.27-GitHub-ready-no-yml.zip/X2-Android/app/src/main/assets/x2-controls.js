(() => {
  'use strict';
  if (window.__x2ControlsInstalled) return;
  window.__x2ControlsInstalled = true;

  const dict = (window.__X2_ZH_DICT__ && window.__X2_ZH_DICT__.strings) || {};
  const appText = (window.__X2_ZH_DICT__ && window.__X2_ZH_DICT__.app) || {};
  const norm = value => String(value || '').replace(/\s+/g, ' ').trim();
  const messages = {
    phone: appText.phoneUnsupported || '您的手机号码不支持',
    google: appText.googleServiceError || '该设备谷歌服务异常',
    apple: appText.appleUnsupported || '不支持非apple系统'
  };
  const overlays = new Map();
  const originalText = new WeakMap();
  let toastTimer = 0;
  let applyQueued = false;
  let observer = null;
  let started = false;

  const css = `
    [data-testid*="getApp" i], [aria-label*="Get the app" i], [aria-label="Get App" i] { display:none !important; visibility:hidden !important; pointer-events:none !important; }
    .x2-hit-overlay { position:fixed !important; z-index:2147483646 !important; display:block !important; margin:0 !important; padding:0 !important; border:0 !important; border-radius:0 !important; opacity:0 !important; pointer-events:auto !important; touch-action:manipulation !important; cursor:pointer !important; }
    .x2-toast { position:fixed !important; z-index:2147483647 !important; left:50% !important; bottom:max(28px,env(safe-area-inset-bottom)) !important; transform:translateX(-50%) !important; max-width:calc(100vw - 40px) !important; padding:12px 18px !important; border-radius:12px !important; background:rgba(25,25,25,.96) !important; color:#fff !important; font:14px/1.45 sans-serif !important; text-align:center !important; box-shadow:0 4px 18px rgba(0,0,0,.25) !important; }
  `;

  function installStyle() {
    const host = document.head || document.documentElement;
    if (!host || document.getElementById('x2-controls-style')) return;
    const style = document.createElement('style');
    style.id = 'x2-controls-style';
    style.textContent = css;
    host.appendChild(style);
  }

  function toast(message) {
    if (!document.body) return;
    let node = document.getElementById('x2-toast');
    if (!node) {
      node = document.createElement('div');
      node.id = 'x2-toast';
      node.className = 'x2-toast';
      node.setAttribute('role', 'status');
      document.body.appendChild(node);
    }
    node.textContent = message;
    node.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { if (node.isConnected) node.hidden = true; }, 2300);
  }

  function buttonText(el) {
    return norm(el && (el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title')));
  }

  function isLoginScreen() {
    if (/\/(i\/flow\/login|login|account\/access)(\/|$)/i.test(location.pathname)) return true;
    return !!document.querySelector('input[autocomplete*="username" i], input[name*="text" i], input[placeholder*="email" i], input[placeholder*="用户名"], input[placeholder*="电子邮箱"]');
  }

  function isLoggedIn() {
    if (/^\/(i\/flow\/login|login)(\/|$)/i.test(location.pathname)) return false;
    return location.pathname === '/home' || location.pathname.startsWith('/home/') ||
      !!document.querySelector('[data-testid="AppTabBar_Home_Link"], [data-testid="SideNav_AccountSwitcher_Button"], [data-testid="AppTabBar_Profile_Link"]');
  }

  function thirdPartyKind(el) {
    const descendants = el && el.querySelectorAll ? Array.from(el.querySelectorAll('[aria-label],[title],[data-testid]'))
      .map(node => `${node.getAttribute('aria-label') || ''} ${node.getAttribute('title') || ''} ${node.getAttribute('data-testid') || ''}`).join(' ') : '';
    const combined = `${buttonText(el)} ${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.getAttribute('data-testid') || ''} ${descendants}`.toLowerCase();
    if (/(使用\s*手机\s*继续|continue\s*with\s*phone|phone\s*number|phone_login)/i.test(combined) || (/phone|手机/i.test(combined) && /continue|继续/i.test(combined))) return 'phone';
    if (/(使用\s*google\s*继续|continue\s*with\s*google|sign\s*in\s*with\s*google|google_login)/i.test(combined) || (/google/i.test(combined) && /continue|继续/i.test(combined))) return 'google';
    if (/(使用\s*apple\s*继续|continue\s*with\s*apple|sign\s*in\s*with\s*apple|apple_login)/i.test(combined) || (/apple/i.test(combined) && /continue|继续/i.test(combined))) return 'apple';
    return null;
  }

  function candidates() {
    return Array.from(document.querySelectorAll('button,[role="button"],a,[tabindex="0"]'));
  }

  function hideGetApp() {
    if (isLoggedIn() || isLoginScreen()) return;
    candidates().forEach(el => {
      const text = buttonText(el);
      const aria = `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''}`;
      const testid = el.getAttribute('data-testid') || '';
      if (!/^(get the app|get app|获取应用)$/i.test(text) && !/(get the app|get app|获取应用)/i.test(aria) && !/get.?app/i.test(testid)) return;
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
      el.setAttribute('aria-hidden', 'true');
      el.setAttribute('tabindex', '-1');
      el.dataset.x2GetAppHidden = '1';
    });
  }

  function rectStyle(overlay, rect) {
    const values = {
      left: `${Math.max(0, rect.left)}px`, top: `${Math.max(0, rect.top)}px`,
      width: `${Math.max(0, rect.width)}px`, height: `${Math.max(0, rect.height)}px`
    };
    Object.entries(values).forEach(([key, value]) => { if (overlay.style[key] !== value) overlay.style[key] = value; });
  }

  function getOverlay(target, key) {
    let overlay = overlays.get(target);
    if (!overlay || !overlay.isConnected || overlay.dataset.x2Overlay !== key) {
      if (overlay && overlay.isConnected) overlay.remove();
      overlay = document.createElement('div');
      overlay.className = 'x2-hit-overlay';
      overlay.dataset.x2Overlay = key;
      overlay.setAttribute('aria-hidden', 'true');
      overlay.addEventListener('click', event => {
        event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
        if (key.startsWith('third:')) toast(messages[key.slice(6)]);
      }, true);
      ['pointerdown','pointerup','touchstart','touchend','mousedown','mouseup'].forEach(type => {
        overlay.addEventListener(type, event => {
          event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
          if (type === 'pointerdown' || type === 'touchstart') {
            const kind = key.startsWith('third:') ? key.slice(6) : null;
            if (kind) toast(messages[kind]);
          }
        }, { capture:true, passive:false });
      });
      document.body.appendChild(overlay);
      overlays.set(target, overlay);
    }
    return overlay;
  }

  function removeStaleOverlays(keep) {
    for (const [target, overlay] of overlays.entries()) {
      if (!keep.has(target) || !target.isConnected) { overlay.remove(); overlays.delete(target); }
    }
  }

  function translateExactText() {
    if (!document.body) return;
    // Only translate exact interface labels. User posts, comments and DMs are not rewritten.
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !norm(node.nodeValue)) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent || /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT)$/i.test(parent.tagName)) return NodeFilter.FILTER_REJECT;
        if (parent.closest('[data-testid="tweetText"],[data-testid="tweetPhoto"],[data-testid="UserDescription"]')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      const raw = node.nodeValue;
      const key = norm(raw);
      if (!Object.prototype.hasOwnProperty.call(dict, key)) return;
      if (!originalText.has(node)) originalText.set(node, raw);
      const leading = raw.match(/^\s*/)?.[0] || '';
      const trailing = raw.match(/\s*$/)?.[0] || '';
      const replacement = dict[key];
      const next = `${leading}${replacement}${trailing}`;
      if (node.nodeValue !== next) node.nodeValue = next;
    });

    document.querySelectorAll('input,textarea,[aria-label],[title]').forEach(el => {
      const ph = el.getAttribute('placeholder');
      if (ph && dict[norm(ph)]) el.setAttribute('placeholder', dict[norm(ph)]);
      const aria = el.getAttribute('aria-label');
      if (aria && dict[norm(aria)]) el.setAttribute('aria-label', dict[norm(aria)]);
      const title = el.getAttribute('title');
      if (title && dict[norm(title)]) el.setAttribute('title', dict[norm(title)]);
    });
  }

  function fixUsernameHint() {
    if (!isLoginScreen()) return;
    document.querySelectorAll('input,textarea').forEach(input => {
      const signature = `${input.getAttribute('autocomplete') || ''} ${input.getAttribute('name') || ''} ${input.getAttribute('aria-label') || ''} ${input.getAttribute('placeholder') || ''}`.toLowerCase();
      const accountInput = /(email|username|user.?name|电子邮箱|电子邮件|用户名|^text$)/i.test(signature)
        && !/(password|验证码|verification|search|搜索)/i.test(signature);
      if (!accountInput) return;
      input.setAttribute('placeholder', appText.usernamePlaceholder || '输入用户名');
      if (!input.getAttribute('aria-label')) input.setAttribute('aria-label', appText.usernamePlaceholder || '输入用户名');
    });
  }

  function interceptThirdParty() {
    const keep = new Set();
    if (!isLoggedIn() && isLoginScreen()) {
      candidates().forEach(el => {
        const kind = thirdPartyKind(el);
        if (!kind) return;
        const rect = el.getBoundingClientRect();
        if (rect.width < 8 || rect.height < 8 || rect.bottom < 0 || rect.top > innerHeight) return;
        const overlay = getOverlay(el, `third:${kind}`);
        rectStyle(overlay, rect);
        keep.add(el);
      });
    }
    removeStaleOverlays(keep);
  }

  function captureBlock(event) {
    const target = event.target;
    const el = target && target.closest ? target.closest('button,[role="button"],a,[tabindex="0"]') : null;
    if (!el) return;
    if (!isLoggedIn() && !isLoginScreen()) {
      const getAppText = `${buttonText(el)} ${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ${el.getAttribute('data-testid') || ''}`;
      if (/(get the app|get app|获取应用)/i.test(getAppText)) {
        event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
        hideGetApp();
        return;
      }
    }
    if (isLoggedIn() || !isLoginScreen()) return;
    const kind = thirdPartyKind(el);
    if (!kind) return;
    if (event.type === 'keydown' && !['Enter',' '].includes(event.key)) return;
    event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
    if (event.type === 'click' || event.type === 'keydown' || event.type === 'touchend' || event.type === 'pointerdown' || event.type === 'touchstart') toast(messages[kind]);
  }

  function autoTranslateVisiblePosts() {
    if (!isLoggedIn()) return;
    document.querySelectorAll('button,[role="button"]').forEach(control => {
      if (control.dataset.x2AutoTranslated === '1') return;
      const label = `${buttonText(control)} ${control.getAttribute('aria-label') || ''} ${control.getAttribute('title') || ''}`.toLowerCase();
      if (!/(translate post|translate this post|翻译帖子|翻译此帖子)/i.test(label)) return;
      const rect = control.getBoundingClientRect();
      if (rect.width < 4 || rect.height < 4 || rect.bottom < 0 || rect.top > innerHeight) return;
      control.dataset.x2AutoTranslated = '1';
      control.click();
    });
  }

  function apply() {
    applyQueued = false;
    if (!document.body) return;
    installStyle();
    hideGetApp();
    fixUsernameHint();
    translateExactText();
    interceptThirdParty();
    autoTranslateVisiblePosts();
  }

  function scheduleApply() {
    if (applyQueued) return;
    applyQueued = true;
    (window.requestAnimationFrame || (fn => setTimeout(fn, 0)))(apply);
  }

  function start() {
    if (started) return;
    started = true;
    installStyle();
    if (document.documentElement) document.documentElement.lang = 'zh-CN';
    const root = document.documentElement;
    if (root) {
      observer = new MutationObserver(scheduleApply);
      observer.observe(root, { childList:true, subtree:true, characterData:true, attributes:true,
        attributeFilter:['placeholder','aria-label','title','data-testid'] });
    }
    ['click','auxclick','pointerdown','pointerup','touchstart','touchend','mousedown','mouseup','keydown'].forEach(type => {
      document.addEventListener(type, captureBlock, { capture:true, passive:false });
    });
    window.addEventListener('resize', scheduleApply, { passive:true });
    window.addEventListener('scroll', scheduleApply, { passive:true, capture:true });
    window.addEventListener('popstate', scheduleApply);
    window.addEventListener('pageshow', scheduleApply);
    window.addEventListener('hashchange', scheduleApply);
    document.addEventListener('visibilitychange', scheduleApply);
    if (document.body) apply();
    scheduleApply();
    // Periodic recovery covers React re-renders and missed mutation/route events.
    setInterval(scheduleApply, 2500);
  }

  if (document.documentElement) start();
  else document.addEventListener('DOMContentLoaded', start, { once:true });
})();
